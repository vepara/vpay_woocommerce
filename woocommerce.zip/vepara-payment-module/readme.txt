=== vepara-payment-module ===
Contributors: KahveDigital
Tags: payment, vepara Payment Modüle
Stable tag: 1.0.0
Requires at least: 4.0
WC requires at least: 5.1.0
WC tested up to: 7.5.1
Tested up to: 6.2
Requires PHP: 7.0

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
License: LGPL v3.0 
License URI: https://www.gnu.org/licenses/lgpl-3.0.en.html

KahveDigital tarafından geliştirilen vepara Woocommerce ödeme modülü. 

== Description ==
vepara woocommerce is the simple and lightweight implementation of vepara.com payment service for woocommerce+. It's licensed under LGPL v3.0 license, therefore feel free to use it in any project or modify the source code.

== Installation ==
Installation

Login your Wordpress admin and navigate to Plugins->Installed Plugins

Find the vepara plugin and activate the module.

After the successful activation of module, navigate to "Woocommerce->settings->Checkout and click vepara payment.

Check the "Enable vepara payment"

Define a title and description for module.

Click Save Changes button then users are ready to pay.

Users will see vepara payment gateway option on their checkout page.

Admin can see order detail under woocommerce menu.

Notice :

If you have installed any other theme on your woocommerce site, you have to copy below folder from this plugin: wp-content/plugin.

For further information please refer to vepara developer portal.

