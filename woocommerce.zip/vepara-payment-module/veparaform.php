<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?> 


<?php if ($error_message) { ?>
    <div class="row">
        <ul class="woocommerce-error" id="errDiv">
            <li>
                <?php echo __('Payment Error.', 'vepara-payment-module') ?>
                <b><?php echo esc_html($error_message); ?></b><br />
                <?php echo __('Please check the form and try again.', 'vepara-payment-module') ?>
            </li>
        </ul>
    </div>
<?php } ?>
<div class="row">
    <div class="col-xs-12">



        <div id="vepara-form" class="veparaform">

            <div class="tum">
                <h3 class="odemeform-baslik"><?php echo __('Payment Form', 'vepara-payment-module') ?></h3>
                <div class="hepsi">

                    <div class="demo-container">
                        <div class="info-window cvc ">
                            <div class="arrow-info"></div>
                            <div class="cvc-info"><img src="<?php echo $vepara_url ?>img/cvc-help.png"></div>
                        </div>

                        <div class="form-group active vepara">
                            <form method="POST" id="veparapostform" action="">

                                <input type="hidden" id="total" name="total">
                                <input type="hidden" id="installment" name="installment">

                                <div class="veparaname veparafull">
                                    <input class="c-card card-name" placeholder="<?php echo __('Name on Card', 'vepara-payment-module'); ?>" type="text" required oninvalid="this.setCustomValidity('Kart sahibinin adını yazınız.')" oninput="setCustomValidity('')" name="card-name" id="card-name">
                                </div>
                                <input value="<?php echo $orderid ?>" name="order_id" type="hidden">

                                <div class="veparacard veparaorta">
                                    <i class="veparacardicon"></i>
                                    <input id="veparacardnumber" class="c-card cardnumber" placeholder="<?php echo __('Card Number', 'vepara-payment-module'); ?>" required oninvalid="this.setCustomValidity('Kartın üzerindeki 16 haneli numarayı giriniz.')" oninput="setCustomValidity('')" type="tel" name="number">
                                </div>


                                <div class="veparaleft veparaexpry">
                                    <input class="c-date c-card" placeholder="<?php echo __('MM/YY', 'vepara-payment-module'); ?>" type="tel" maxlength="7" required oninvalid="this.setCustomValidity('Kartın son kullanma tarihini giriniz')" oninput="setCustomValidity('')" name="expiry">
                                </div>

                                <div class="vepararight veparacvc">
                                    <input class="card-cvc c-card" placeholder="CVC" required type="number" oninvalid="this.setCustomValidity('Kartın arkasındaki 3 ya da 4 basamaklı sayıyı giriniz')" oninput="setCustomValidity('')" name="cvc">
                                    <div class="vepara-i-icon"><img src="<?php echo $vepara_url ?>img/icons/info.png" width="14px"> </div>
                                </div>

                        </div>

                    </div>

                    <!-- <div class="tekcekim-container ">

                        <div class="tekcekim">

                            <li class="taksit-li " for="s-option">
                                <input type="radio" id="s-option" name="veparatotal" value="<?php echo $showtotal ?>" checked class="option-input taksitradio radio ">
                                <label for="s-option">Tek Çekim</label>
                                <div class="taksit-fiyat"> <?php echo $showtotal; ?></div>
                                <div class="check">
                                    <div class="inside"></div>
                                </div>
                            </li>

                            <div class="taksit-secenek">
                                <?php if ($installments_mode == 'on') { ?>
                                    <h3 class="taksit-secenekleri"><?php echo __('All Installment', 'vepara-payment-module'); ?></h3>

                                    <div class="logolar-vepara">

                                        <?php foreach ($rates as $bank => $rate) { ?>



                                            <div class="vepara-banka-logo <?php echo $bank; ?>-logo"><img src="<?php echo $vepara_url ?>img/<?php echo $bank ?>.svg"></img></div>


                                        <?php } ?>
                                    </div>

                                <?php } ?>
                            </div>
                        </div>
                    </div> -->
                        <div class="taksit-container ">
                                
                                
                        </div>
                    <button type="submit" class="veparaode" style=""><span class="veparaOdemeTutar"><?php echo $showtotal; ?></span><span class="currency"> <?php echo $currency; ?></span><span class="veparaOdemeText"> <?php echo __('Pay', 'vepara-payment-module'); ?></span></button>
                    </form>

                </div>


            </div>
            <div class="card-wrapper" style="margin-left:5px;"></div>
        </div>


    </div>
</div>

<script>
    var theme = "<?php echo esc_url($vepara_url) ?>";
    var taksit = "<?php echo esc_html($installments_mode) ?>";
</script>


<script type="text/javascript">
       
   $= jQuery;
   $(document).ready(function() {
    new Card({
        form: document.querySelector('.hepsi'),
        container: '.card-wrapper',
        formSelectors: {

            nameInput: 'input#card-name'
        },

    });

        $('input[type=radio][name=veparatotal]').change(function() {

            $('.veparaOdemeTutar').text(this.value);
            $('.currency').text(" <?php echo $currency; ?>");
        });


    // if (taksit == 'on') {
        if (true) {
            cardshow(0);
                 $(".bonus-logo").click(function() {
                cardshow(0);
                $(".taksit-container").show();
                $(".bonus").show();
                $("#s-option_bonus_1").prop('checked', true);
            });





            function cardshow(bankcode) {
                if (bankcode == '0') {
                    // $(".taksit-container").hide();
                    // $(".taksit-container").children().hide();
                } else if (bankcode==20) {
                    // $(".taksit-container").hide();
                    // // $(".taksit-container").children().hide();
                    // $(".taksit-container").show();
                    // $('.bonus').show();
                    // $("#s-option_bonus_1").prop('checked', true);
                } 
            }
            $.ajaxSetup({
                cache: false
            });
            $('#veparacardnumber').keyup(function() {

                var searchField = $('#veparacardnumber').val();
                searchField = searchField.replace(/\s/g, '');
                if (searchField.length < 6) {
                    const taksitContainer = document.querySelector(".taksit-container");
                    taksitContainer.innerHTML = "";
                    return;
                };
                if (searchField.length > 6)
                    return;


                jQuery.ajax({
                    type: "POST",
                    url: "/vepara-payment-module/wc-api/veparapay/",
                    data: {
                        BinNumber: searchField,
                        OrderId: "<?php echo $orderid ?>",
                    },
                    success: function(data) {
                        var response = JSON.parse(data);
                        if (response.status=='success') {
                            const installments = response.data.data;
                            const divElement = document.createElement('div');
                            divElement.classList.add('taksit-title');

                            if(installments[0]["card_program"] != ""){
                                const imgElement = document.createElement('img');
                                imgElement.src = `<?php echo $vepara_url?>img/${installments[0]["card_program"].toLowerCase()}.svg`;
                                divElement.appendChild(imgElement);
                            }


                            // const ulElement = document.createElement('ul');
                            const taksitContainer = document.querySelector(".taksit-container");
                            taksitContainer.appendChild(divElement);

                            for(let i = 0; i < installments.length; i++){
                                if(taksit != 'on' && i > 0){
                                    break;
                                }
                                const liElement = document.createElement('li');
                                liElement.classList.add('taksit-li', 'veparaorta');

                                const totalElement = document.createElement('div');
                                totalElement.classList.add("total-loc");
                                totalElement.setAttribute('data-value', installments[i].amount_to_be_paid);
                                const installmentElement = document.createElement('div');
                                installmentElement.classList.add("installment-loc");
                                installmentElement.setAttribute('data-value', installments[i].installments_number);

                                const spanElement = document.createElement('span');
                                spanElement.innerText = (i+1) + " Taksit";
                                if(i == 0){
                                    spanElement.innerText = "Tek Çekim";
                                }

                                const inputElement = document.createElement('input');
                                inputElement.type = 'radio';
                                inputElement.id = `s-option_${installments[i]["card_program"].toLowerCase()}_` + i;
                                inputElement.name = `veparatotal[${installments[i]["card_program"].toLowerCase()}][${i}]`;
                                inputElement.value = installments[i].amount_to_be_paid;
                                inputElement.classList.add('option-input', 'taksitradio', 'radio');

                                const labelElement = document.createElement('label');
                                labelElement.setAttribute('for', `s-option2`);
                                labelElement.textContent = `${installments[i].amount_to_be_paid} ${installments[i].currency_code}`;

                                const divFiyatElement = document.createElement('div');
                                divFiyatElement.classList.add('taksit-fiyat');
                                divFiyatElement.textContent = `${(installments[i].amount_to_be_paid / installments[i].installments_number).toFixed(2)} ${installments[i].currency_code} * ${installments[i].installments_number}`;

                                const divCheckElement = document.createElement('div');
                                divCheckElement.classList.add('check');

                                const divInsideElement = document.createElement('div');
                                divInsideElement.classList.add('inside');

                                divCheckElement.appendChild(divInsideElement);
                                liElement.appendChild(totalElement);
                                liElement.appendChild(installmentElement);
                                liElement.appendChild(spanElement);
                                liElement.appendChild(inputElement);
                                liElement.appendChild(labelElement);
                                liElement.appendChild(divFiyatElement);
                                liElement.appendChild(divCheckElement);
                                taksitContainer.appendChild(liElement);
                                // ulElement.appendChild(liElement);
                            }

                           
                            // taksitContainer.appendChild(ulElement);

                            $(".taksit-li").click(function(el) {
                                document.querySelector("#installment").value = $(this).find('.installment-loc').attr("data-value");
                                document.querySelector("#total").value =  $(this).find('.total-loc').attr("data-value");

                                $(".taksit-li").find('input[type="radio"]').removeAttr('checked');
                                $(this).find('input[type="radio"]').prop('checked', true);
                                var price = $(this).find('input[type="radio"]').val();
                                $('.veparaOdemeTutar').text(price);
                            });
                            
                            $(`#s-option_${installments[0]["card_program"].toLowerCase()}_0`).prop('checked', true);
                            // İlk değerlerin inputlara atılması.
                            document.querySelector("#installment").value = 1;
                            document.querySelector("#total").value = installments[0].amount_to_be_paid;
                            document.querySelector(".veparaOdemeTutar").innerHTML = installments[0].amount_to_be_paid;
                            
                        }else{
                            const taksitContainer = document.querySelector(".taksit-container");
                            taksitContainer.innerHTML = "Geçersiz Bin Number";
                            return;
                        }
                    },
                    error: function(errorThrown) {
                        alert(errorThrown);
                        console.log(errorThrown);
                        console.log(data);
                    }

                });




            });

    
    }

    $(".vepara-i-icon img").hover(function() {
        $(".info-window").toggleClass("info-window-active");
    });

    $('.c-card').bind('keypress keyup keydown focus', function(e) {
        var ErrorInput = false;
        if ($("input.card-name").hasClass("jp-card-invalid")) {
            ErrorInput = true;
            $("input.card-name").addClass("border");
        }
        if ($("input.cardnumber").hasClass("jp-card-invalid")) {
            ErrorInput = true;
            $("input.cardnumber").addClass("border");
        }
        if ($("input.c-date").hasClass("jp-card-invalid")) {
            ErrorInput = true;
            $("input.c-date").addClass("border");
        }
        if ($("input.card-cvc").hasClass("jp-card-invalid")) {
            ErrorInput = true;
            $("input.card-cvc").addClass("border");
        }
        if (ErrorInput === true) {
            $('.veparaode').attr("disabled", true);
            $(".veparaode").css("opacity", "0.5");

        } else {

            $("input.card-name").removeClass("border");
            $("input.cardnumber").removeClass("border");
            $("input.c-date").removeClass("border");
            $("input.card-cvc").removeClass("border");
            $('.veparaode').attr("disabled", false);
            $(".veparaode").css("opacity", "1");

        }

    });
});
</script>