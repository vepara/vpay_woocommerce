<?php

/*
 * Plugin Name: vepara Payment Gateway for woocommerce
 * Plugin URI: https://www.vepara.com.tr/
 * Description: vepara Payment gateway for woocommerce
 * Version: 1.0.0
 * Author: kahvedigital
 * Author URI: https://kahvedigital.com
 * Domain Path: /i18n/languages/
 */

if (!defined('ABSPATH')) {
    exit;
}

include plugin_dir_path(__FILE__) . 'includes/class-veparaconfig.php';
global $vepara_db_version;
$vepara_db_version = '1.0';
register_deactivation_hook(__FILE__, 'vepara_deactivation');
register_activation_hook(__FILE__, 'vepara_activate');
add_action('plugins_loaded', 'vepara_update_db_check');

function vepara_update_db_check()
{
    global $vepara_db_version;
    global $wpdb;
    $installed_ver = get_option("vepara_db_version");
    if ($installed_ver != $vepara_db_version) {
        vepara_update();
    }
}

function vepara_update()
{
    global $vepara_db_version;
    update_option("vepara_db_version", $vepara_db_version);
}

function vepara_activate()
{
    global $wpdb;
    global $vepara_db_version;
    $vepara_db_version = '1.0';

    $charset_collate = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    add_option('vepara_db_version', $vepara_db_version);
}

function vepara_deactivation()
{
    global $wpdb;
    global $vepara_db_version;

    delete_option('vepara_db_version');
    flush_rewrite_rules();
}

function vepara_install_data()
{
    global $wpdb;
}

add_action('plugins_loaded', 'woocommerce_vepara_from_init', 0);

function woocommerce_vepara_from_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Gateway_VeparaPay extends WC_Payment_Gateway
    {

        public function __construct()
        {
            $this->id = 'veparapay';
            $this->method_title = __('vepara Checkout form', 'vepara-payment-module');
            $this->method_description = __('vepara Payment Module', 'vepara-payment-module');
            $this->icon = plugins_url('/vepara-payment-module/img/cards.png', dirname(__FILE__));
            $this->has_fields = false;
            $this->supports = array('products', 'refunds');
            $this->rates = get_option('vepara_rates');
            $this->init_form_fields();
            $this->init_settings();

            $this->veparapay_tdmode = $this->settings['veparapay_tdmode'];
            $this->veparapay_testmode = $this->settings['veparapay_testmode'];
            $this->veparapay_companyname = $this->settings['veparapay_companyname'];
            $this->veparapay_provuserpassword = $this->settings['veparapay_provuserpassword'];
            $this->veparapay_terminalsotrekey = $this->settings['veparapay_terminalsotrekey'];
            $this->veparapay_provuserid = $this->settings['veparapay_provuserid'];
            $this->veparapay_terminalid = $this->settings['veparapay_terminalid'];
            $this->veparapay_terminalmerchantid = $this->settings['veparapay_terminalmerchantid'];
            $this->veparapay_3dtutar = $this->settings['veparapay_3dtutar'];
            $this->installments_mode = $this->settings['installments_mode'];

            $this->veparapay_app_id = $this->settings['veparapay_app_id'];
            $this->veparapay_key = $this->settings['veparapay_key'];
            $this->veparapay_app_secret = $this->settings['veparapay_app_secret'];

            $this->title = $this->settings['title'];
            $this->description = $this->settings['description'];
            $this->enabled = $this->settings['enabled'];
            $this->order_button_text = $this->settings['button_title'];

            $this->remote_url = null;
            if($this->veparapay_testmode == "TEST"){
                $this->remote_url = "https://test.vepara.com.tr";
            }else{
                $this->remote_url = "https://app.vepara.com.tr";
            }

            add_action('woocommerce_receipt_veparapay', array($this, 'receipt_page'));
            add_action('init', array(&$this, 'check_veparapay_response'));
            add_action('woocommerce_api_wc_gateway_veparapay', array($this, 'check_veparapay_response'));
            add_action('admin_notices', array($this, 'checksFields'));
            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array($this, 'process_admin_options'));
            }
    
            add_action('woocommerce_api_wc_gateway_veparapay', array($this, 'check_vepara_response'));
     
            add_action('woocommerce_api_' . $this->id, array($this, 'binCheckVepara'));
          //  add_action('woocommerce_api_renw' . $this->id, array($this, 'renewBinFile'));
    
        }
      
 
     
        function binCheckVepara()
        {
            header('HTTP/1.1 200 OK');
            $binNumber = wc_clean($_POST['BinNumber']);
            // $file = plugin_dir_path(__FILE__) . '/bins.json';
            // $strJsonFileContents = file_get_contents($file);
            // $json = json_decode($strJsonFileContents);
            $array = ['status' => 'failure'];
            // print_r($_POST);
            $order = new WC_Order($_POST["OrderId"]);

            $data = array(
                "credit_card" => $binNumber,
                "amount" => $order->get_total(),
                "currency_code" => $order->get_currency(),
                "merchant_key" => $this->veparapay_key,
            );
            $installmentResponse = $this->curlPostExtPos($data, $this->remote_url . "/ccpayment/api/getpos");
            
            $array = ['status' => 'success', 'data' => json_decode($installmentResponse)];

            print_r(json_encode($array));
            die();
        }

        function checksFields()
        {
            global $woocommerce;

            if ($this->enabled == 'no') {
                return;
            }
        }

        function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'vepara-payment-module'),
                    'label' => __('Enable vepara Form', 'vepara-payment-module'),
                    'type' => 'checkbox',
                    'default' => 'no',
                ),
                'title' => array(
                    'title' => __('Title', 'vepara-payment-module'),
                    'type' => 'text',
                    'description' => __('This message will show to the user during checkout.', 'vepara-payment-module'),
                    'default' => 'Kredi Kartı İle Öde',
                ),
                'description' => array(
                    'title' => __('Description.', 'vepara-payment-module'),
                    'type' => 'text',
                    'description' => __('This controls the description which the user sees during checkout.', 'vepara-payment-module'),
                    'default' => __('Pay with your credit card via vepara.', 'vepara-payment-module'),
                    'desc_tip' => true,
                ),
                'button_title' => array(
                    'title' => __('Checkout Button.', 'vepara-payment-module'),
                    'type' => 'text',
                    'description' => __('Checkout Button.', 'vepara-payment-module'),
                    'default' => __('Pay with vepara.', 'vepara-payment-module'),
                    'desc_tip' => true,
                ),
                'veparapay_3dtutar' => array(
                    'title' => __('3d Secure Geçilecek Tutar', 'vepara-payment-module'),
                    'type' => 'text',
                    'description' => __('3d Siz ödemenin sonlanacağı ödeme tutarı.', 'vepara-payment-module'),

                ),
                'veparapay_app_id' => array(
                    'title' => __('vepara app  ID .', 'vepara-payment-module'),
                    'type' => 'text',
                    'desc_tip' => __('Password Given by app ID System.', 'vepara-payment-module'),
                ),
                'veparapay_app_secret' => array(
                    'title' => __('vepara app secret.', 'vepara-payment-module'),
                    'type' => 'text',
                    'desc_tip' => __('app secret Given by vepara System.', 'vepara-payment-module'),
                ),
                'veparapay_key' => array(
                    'title' => __('vepara key .', 'vepara-payment-module'),
                    'type' => 'text',
                    'desc_tip' => __('key Given by vepara System.', 'vepara-payment-module'),
                ),
                'veparapay_tdmode' => array(
                    'title' => __('Three D Selection.', 'vepara-payment-module'),
                    'type' => 'select',
                    'default' => 'off',
                    'options' => array(
                        'off' => __('OFF', 'vepara-payment-module'),
                        'on' => __('ON', 'vepara-payment-module'),
                    ),
                ),
                'veparapay_testmode' => array(
                    'title' => __('Test Modu', 'vepara-payment-module'),
                    'type' => 'select',
                    'default' => 'off',
                    'options' => array(
                        'TEST' => __('TEST', 'vepara-payment-module'),
                        'PROD' => __('PROD', 'vepara-payment-module'),
                    ),
                ),
                'installments_mode' => array(
                    'title' => __('Installments Options.', 'vepara-payment-module'),
                    'type' => 'select',
                    'default' => 'off',
                    'options' => array(
                        'off' => __('OFF', 'vepara-payment-module'),
                        'on' => __('ON', 'vepara-payment-module'),
                    ),
                ),
            );
        }

        public function admin_options()
        {
            $this->rates = get_option('veparapay_rates');
            if (isset($_POST['veparapay_rates'])) {
                VeparaPay::register_all_ins();
            }
            $vepara_url = plugins_url() . '/vepara-payment-module/';
            echo '<img src="' . $vepara_url . 'img/logo.png" width="150px" />';
            echo '<h2>vepara Sanal Pos ayarları</h2>
            <hr />';
            include dirname(__FILE__) . '/includes/vepara-help-about.php';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';

          //  if ($this->rates == false) {
               //   $installments = VeparaPay::createRatesUpdateForm(VeparaPay::setRatesDefault());
            // } else {
                //  $installments = VeparaPay::createRatesUpdateForm(get_option('veparapay_rates'));
            // }
           //  echo "<hr/><h1>";
            // echo __('installments options.', 'vepara-payment-module');
            // echo "</h1><hr />";
            // echo $installments;
        }

        private function setcookieSameSite($name, $value, $expire, $path, $domain, $secure, $httponly)
        {

            if (PHP_VERSION_ID < 70300) {
                setcookie($name, $value, $expire, "$path; samesite=None", $domain, $secure, $httponly);
            } else {
                setcookie($name, $value, [
                    'expires' => $expire,
                    'path' => $path,
                    'domain' => $domain,
                    'samesite' => 'None',
                    'secure' => $secure,
                    'httponly' => $httponly,
                ]);
            }
        }

        function vepara_format_number($number) {
            // Sayıyı string'e dönüştür
            $number_str = (string)$number;
            
            // Sayının uzunluğunu al
            $length = strlen($number_str);
            
            // Eğer sayı 2 haneden azsa, başına sıfır ekle
            if ($length < 2) {
                return "0.$number_str";
            }
            
            // Son iki haneyi ayır ve geriye kalan kısmı al
            $last_two_digits = substr($number_str, -2);
            $remaining_digits = substr($number_str, 0, $length - 2);
            
            // Geriye kalan kısım boşsa, sıfır olarak ayarla
            if ($remaining_digits == '') {
                $remaining_digits = '0';
            }
            
            // Noktayı ekleyerek formatla
            $formatted_number = $remaining_digits . '.' . $last_two_digits;
            
            return $formatted_number;
        }

        function post2veparaPay($order_id)
        {
            global $woocommerce;


            if (version_compare(get_bloginfo('version'), '4.5', '>=')) {
                wp_get_current_user();
            } else {
                get_currentuserinfo();
            }
            $order = new WC_Order($order_id);
            $wooCommerceCookieKey = 'wp_woocommerce_session_';
            foreach ($_COOKIE as $name => $value) {
                if (stripos($name, $wooCommerceCookieKey) === 0) {
                    $wooCommerceCookieKey = $name;
                }
            }
            $wooCommerceCookieKey = sanitize_text_field($wooCommerceCookieKey);
            $setCookie = $this->setcookieSameSite($wooCommerceCookieKey, $_COOKIE[$wooCommerceCookieKey], time() + 86400, "/", $_SERVER['SERVER_NAME'], true, true);


            $ip = $_SERVER['REMOTE_ADDR'];

            $user_meta = get_user_meta(get_current_user_id());

            if (!function_exists('replaceSpace')) {

                function replaceSpace($veri)
                {
                    $veri = str_replace("/s+/", "", $veri);
                    $veri = str_replace(" ", "", $veri);
                    $veri = str_replace(" ", "", $veri);
                    $veri = str_replace(" ", "", $veri);
                    $veri = str_replace("/s/g", "", $veri);
                    $veri = str_replace("/s+/g", "", $veri);
                    $veri = trim($veri);
                    return $veri;
                }
            }

            $name = wc_clean($_POST['card-name']);
            $number = wc_clean($_POST['number']);
            $expiry = wc_clean($_POST['expiry']);
            $cvc = wc_clean($_POST['cvc']);
            $paid = wc_clean($_POST['total']);
            $installement = wc_clean($_POST['installment']);

            // print_r($paid);
            // die();
            
            if( ($this->installments_mode == "OFF" || $this->installments_mode == false) && $installement != 1 ){
                throw new Exception("Installment not allowed!");
            }

            $expiry = explode("/", $expiry);
            $expiryMM = $expiry[0];
            $expiryYY = $expiry[1];
            $expiryMM = replaceSpace($expiryMM);
            $expiryYY = replaceSpace($expiryYY);
            $number = replaceSpace($number);

            $tutar3dclsoe = number_format($this->veparapay_3dtutar, 2, '', '');

            $user_id = get_current_user_id();
            $currency = $order->get_currency();
            $email = !empty($order->get_billing_email()) ? $order->get_billing_email() : 'vepara@vepara.com.tr';
            $ucdaktif = $this->veparapay_tdmode;
            $orderid = $order_id . "A" . uniqid();
            session_start();
            $_SESSION['orderIdForvepara'] = $orderid;
            $_SESSION['orderAmountForvepara'] = $paid;
            $_SESSION['installment'] = $installement;

            if (($ucdaktif == 'on') || ($ucdaktif == 'off' && $paid > $tutar3dclsoe)) {
                // 3d

                $ProductsBasket = $this->generateBasketItems($customerCart, $order);

                $sum = 0;
                foreach ($ProductsBasket as $product) {
                    $sum += $product->price;
                }
                
                // Farkı hesaplama
                $diff = $paid - $sum;

                $newProduct = (object)[
                    'name' => 'Installment Fee',
                    'description' => 'Installment Fee',
                    'quantity' => 1,
                    'price' => $diff
                ];
                $ProductsBasket[] = $newProduct;

                $data= array(
                'cc_holder_name' => $name,
                'cc_no' =>  $number,
                'expiry_month' =>  $expiryMM,
                'expiry_year' => "20".$expiryYY,
                'currency_code' =>  $currency,
                'cvv' =>  $cvc,
                'installments_number' => $installement,
                'invoice_id' =>  $orderid,
                'invoice_description' => 'ewrwer',
                'total' => $paid,
                'merchant_key' => $this->veparapay_key,
                'items' =>  $ProductsBasket,
                'name' =>  $order->get_billing_first_name(),
                'surname' => $order->get_billing_last_name(),
                'hash_key' => $this->hashGenerator($currency,$this->veparapay_key,$orderid,$this->veparapay_app_secret,$paid,$installement),
                'return_url' => add_query_arg('wc-api', 'WC_Gateway_VeparaPay', $order->get_checkout_order_received_url()) . "&action=success",
                'cancel_url' => add_query_arg('wc-api', 'WC_Gateway_VeparaPay', $order->get_checkout_order_received_url()) . "&action=error",
                );

                // $strHostAddress ="https://app.vepara.com.tr/ccpayment/api/paySmart3D";
                // if ($this->veparapay_testmode == "TEST") {
                //     $strHostAddress = "https://test.vepara.com.tr/ccpayment/api/paySmart3D";
                // }

                $response = $this->curlPostExt($data, $this->remote_url . "/ccpayment/api/paySmart3D", true);
                print_r($response);

            } else {
                //3dClose...
                // $strHostAddress ="https://app.vepara.com.tr/ccpayment/api/paySmart2D";
                // if ($this->veparapay_testmode == "TEST") {
                //     $strHostAddress = "https://test.vepara.com.tr/ccpayment/api/paySmart2D";
                // }

                $ProductsBasket = $this->generateBasketItems($customerCart, $order);
 
                $data= array( 'cc_holder_name' => $name,
                    'cc_no' =>  $number,
                    'expiry_month' =>  $expiryMM,
                    'expiry_year' => "20".$expiryYY,
                    'currency_code' =>  $currency,
                    'installments_number' => $installement,
                    'invoice_id' =>  $orderid,
                    'invoice_description' => 'ewrwer',
                    'total' => $paid,
                    'merchant_key' => $this->veparapay_key,
                    'items' =>  $ProductsBasket,
                    'name' =>  $order->get_billing_first_name(),
                    'surname' => $order->get_billing_last_name(),
                    'hash_key' => $this->hashGenerator($currency,$this->veparapay_key,$orderid,$this->veparapay_app_secret,$paid,$installement),
                    'cancel_url' => add_query_arg('wc-api', 'WC_Gateway_VeparaPay', $order->get_checkout_order_received_url()) . "&action=error");

                    $response = $this->curlPostExt($data, $this->remote_url . "/ccpayment/api/paySmart2D", true);
                    $response = json_decode($response, true);

                    $bolunmus = explode("A", $_SESSION['orderIdForvepara']);
                    $orderid = $bolunmus[0];
                    $order = new WC_Order($orderid);

                    if($response['status_code'] == 100){
                        // 2D Success
                        $order_amount = $order->get_total();
                        $order_amount = round($order_amount, 2);
                        $installment_fee = $postParams["product_price"];
                        $order_fee = new stdClass();
                        $order_fee->id = 'Total';
                        $order_fee->name = __('Total', 'vepara-payment');
                        $order_fee->amount = $installment_fee;
                        $order_fee->taxable = false;
                        $order_fee->tax = 0;
                        $order_fee->tax_data = array();
                        $order_fee->tax_class = '';
                        $fee_id = $order->add_fee($order_fee);
                        $order->calculate_totals(true);
                        update_post_meta($orderid, 'vepara_installment_number', esc_sql($installment));
                        update_post_meta($orderid, 'vepara_installment_fee', $installment_fee);
    
    
                        $orderMessage = 'Payment ID: ' . $response['data']['invoice_id'];
                        $order->add_order_note($orderMessage, 0, true);
                        $order->payment_complete();
                        WC()->cart->empty_cart();
                        $woocommerce->cart->empty_cart();

                        $checkoutOrderUrl = $order->get_checkout_order_received_url();
                        $redirectUrl = add_query_arg(array('msg' => 'Thank You', 'type' => 'woocommerce-message'), $checkoutOrderUrl);
                        return wp_redirect($redirectUrl);
                    }else{
                        // 2D Failure. Payment Failed.
                        if (is_array($response['original_bank_error_description'])) {
                            $response['original_bank_error_description'] =  $response['original_bank_error_description'][0];
                        }

                        if (is_object($response['original_bank_error_description'])) {
                            $response['original_bank_error_description'] =  (array) $response['original_bank_error_description'];
                            $response['original_bank_error_description'] =  $response['original_bank_error_description'][0];
                        }
                        $message = sanitize_text_field($response['original_bank_error_description']);
                        $errorMessage = isset($message) ? $message : 'Failed';

                        $message = $errorMessage;
                        $order = new WC_Order($orderid);
                        $order->update_status('failed', sprintf(__('vepara payment failed', 'vepara-payment'), $message));
                        $order->add_order_note($message, 0, true);
                        wc_add_notice(__($message, 'vepara-payment'), 'error');
                        $redirectUrl = $woocommerce->cart->get_cart_url();
                        return wp_redirect($redirectUrl);
                    }
            }
        }

        public  function hashGenerator($currency_code,$merchant_key,$invoice_id,$app_secret,$total,$installments_number)
        {
               
          $data = $total . '|' . $installments_number . '|' . $currency_code . '|' . $merchant_key . '|' . $invoice_id;
          $iv = substr(sha1(mt_rand()), 0, 16);
          $password = sha1($app_secret);
          $salt = substr(sha1(mt_rand()), 0, 4);
          $saltWithPassword = hash('sha256', $password . $salt);
          $encrypted = openssl_encrypt(
              $data, 'aes-256-cbc', $saltWithPassword, 0, $iv
          );
          $msg_encrypted_bundle = $iv . ':' . $salt . ':' . $encrypted;
          $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
          return $msg_encrypted_bundle;
        }
        public function generateBasketItems($items, $order)
        {

            $itemSize = count($items);

            if (!$itemSize) {

                return $this->calcProduct($order);
            }

            $keyNumber = 0;

            foreach ($items as $key => $item) {

                $productId = $item['product_id'];
                $product = wc_get_product($productId);
                $realPrice = $this->realPrice($item['line_subtotal'], $product->get_price());
             
                if ($realPrice && $realPrice != '0' && $realPrice != '0.0' && $realPrice != '0.00' && $realPrice != false) {

                    $basketItems[$keyNumber] = new stdClass();

                    $basketItems[$keyNumber]->quantity = $item['product_id'];
                    $basketItems[$keyNumber]->price = $this->priceParser(round($realPrice, 2));
                    $basketItems[$keyNumber]->name = $product->get_title();
                    $basketItems[$keyNumber]->description = "";

                    $keyNumber++;

                }

            }


        }

        public function calcProduct($order)
        {

            $keyNumber = 0;

            $basketItems[$keyNumber] = new stdClass();

            $basketItems[$keyNumber]->description = "Default";
            $basketItems[$keyNumber]->price = $this->priceParser(round($order->get_total(), 2));
            $basketItems[$keyNumber]->name = 'Woocommerce - Custom Order Page';
            $basketItems[$keyNumber]->quantity = 1;

            return $basketItems;
        }

        public function priceParser($price)
        {

            if (strpos($price, ".") === false) {
                return $price . ".0";
            }
            $subStrIndex = 0;
            $priceReversed = strrev($price);
            for ($i = 0; $i < strlen($priceReversed); $i++) {
                if (strcmp($priceReversed[$i], "0") == 0) {
                    $subStrIndex = $i + 1;
                } else if (strcmp($priceReversed[$i], ".") == 0) {
                    $priceReversed = "0" . $priceReversed;
                    break;
                } else {
                    break;
                }
            }

            return strrev(substr($priceReversed, $subStrIndex));
        }

        function receipt_page($orderid)
        {
            global $woocommerce;
            $error_message = false;
            $order = new WC_Order($orderid);
            $rates = VeparaPay::calculatePrices($order->get_total(), $this->rates);
            $status = $order->get_status();
            $showtotal = $order->get_total();
            $currency = $order->get_currency();
            $installments_mode = $this->installments_mode;

            if(isset($_POST['order_id'])){
                $orderIdPost=wc_clean($_POST['order_id']);
            }
            if (isset($orderIdPost) and $orderIdPost == $orderid) {
          
                $record = $this->post2veparaPay($orderid);
            }

            $record['result'] = false;

            if ($status != 'pending') {
                $order->get_status();
            }
            $vepara_url = plugins_url() . '/vepara-payment-module/';
            wp_enqueue_script('vepara-cardjs-scripts',$vepara_url.'/assets/js/card.js');
            wp_enqueue_style( 'vepara-style',$vepara_url . 'assets/css/vepara.css', false, '1.0', 'all' ); // Inside a parent theme
            include dirname(__FILE__) . '/veparaform.php';
        }
        public function check_veparapay_response()
        {

            global $woocommerce;
            session_start();

            $installment = $_SESSION['installment'];
            $bolunmus = explode("A", $_SESSION['orderIdForvepara']);
            $orderid = $bolunmus[0];
            $order = new WC_Order($orderid);

            // print_r($_GET);

            if($_GET["status_code"] == 100 && $_GET["payment_status"] == 1){
                $params = array(
                    "invoice_id" => $_GET["invoice_id"],// $orderid,// $_GET["invoice_id"],
                    "merchant_key" => $this->veparapay_key
                );
                $result = json_decode($this->curlPostExt($params, $this->remote_url . "/ccpayment/api/checkstatus"), true);

                // Check Payment If it is really successfull
                if ($result['transaction_status'] == "Completed") {
                    // Payment Successfull

                    $order_amount = $order->get_total();
                    $order_amount = round($order_amount, 2);
                    $installment_fee = $postParams["product_price"];
                    $order_fee = new stdClass();
                    $order_fee->id = 'Total';
                    $order_fee->name = __('Total', 'vepara-payment');
                    $order_fee->amount = $installment_fee;
                    $order_fee->taxable = false;
                    $order_fee->tax = 0;
                    $order_fee->tax_data = array();
                    $order_fee->tax_class = '';
                    $fee_id = $order->add_fee($order_fee);
                    $order->calculate_totals(true);
                    update_post_meta($orderid, 'vepara_installment_number', esc_sql($installment));
                    update_post_meta($orderid, 'vepara_installment_fee', $installment_fee);


                    $orderMessage = 'Payment ID: ' . $result['invoice_id'];
                    $order->add_order_note($orderMessage, 0, true);
                    $order->add_order_note("Installment Number: " . $installment, 0, true);
                    $order->payment_complete();
                    WC()->cart->empty_cart();
                    $woocommerce->cart->empty_cart();

                    $checkoutOrderUrl = $order->get_checkout_order_received_url();
                    $redirectUrl = add_query_arg(array('msg' => 'Thank You', 'type' => 'woocommerce-message'), $checkoutOrderUrl);
                    return wp_redirect($redirectUrl);
                }else{
                    // Payment Failed.
                    if (is_array($result['status_description'])) {
                        $result['status_description'] =  $result['status_description'][0];
                    }

                    if (is_object($result['status_description'])) {
                        $result['status_description'] =  (array) $result['status_description'];
                        $result['status_description'] =  $result['status_description'][0];
                    }
                    $message = sanitize_text_field($result['status_description']);
                    $errorMessage = isset($message) ? $message : 'Failed';

                    
                    $message = $errorMessage;
                    $order = new WC_Order($orderid);
                    $order->update_status('failed', sprintf(__('vepara payment failed', 'vepara-payment'), $message));
                    $order->add_order_note($message, 0, true);
                    wc_add_notice(__($message, 'vepara-payment'), 'error');
                    
                    $redirectUrl = $woocommerce->cart->get_cart_url();
                    return wp_redirect($redirectUrl);
                }
            }else{
                // Payment Failed.
                if (is_array($_GET['original_bank_error_description'])) {
                    $_GET['original_bank_error_description'] =  $_GET['original_bank_error_description'][0];
                }

                if (is_object($_GET['original_bank_error_description'])) {
                    $_GET['original_bank_error_description'] =  (array) $_GET['original_bank_error_description'];
                    $_GET['original_bank_error_description'] =  $_GET['original_bank_error_description'][0];
                }
                $message = sanitize_text_field($_GET['original_bank_error_description']);
                $errorMessage = isset($message) ? $message : 'Failed';

                
                $message = $errorMessage;
                $order = new WC_Order($orderid);
                $order->update_status('failed', sprintf(__('vepara payment failed', 'vepara-payment'), $message));
                $order->add_order_note($message, 0, true);
                wc_add_notice(__($message, 'vepara-payment'), 'error');

                $redirectUrl = $woocommerce->cart->get_cart_url();
                return wp_redirect($redirectUrl);
            }
      
            die();
        }
        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);

            if (version_compare(WOOCOMMERCE_VERSION, '2.1.0', '>=')) {
                /* 2.1.0 */
                $checkout_payment_url = $order->get_checkout_payment_url(true);
            } else {
                /* 2.0.0 */
                $checkout_payment_url = get_permalink(get_option('woocommerce_pay_page_id'));
            }

            return array(
                'result' => 'success',
                'redirect' => $checkout_payment_url,
            );
        }
        function curlPostExt($data, $url, $json = false)
        {

            $returnToken= $this->getToken();
            //print_r(json_decode($returnToken, true)["data"]["token"]);
            //die();
            $response = wp_remote_post($url, array(
                'headers' => array('Content-type' => 'application/json', 'user-agent'=>$_SERVER['HTTP_USER_AGENT'], 'Authorization'=> 'Bearer ' . json_decode($returnToken, true)["data"]["token"]),
                'body' => json_encode($data),
                'method' => 'POST',
                'data_format' => 'body',
            ));
            $body = wp_remote_retrieve_body($response);

            return $body;
        }

        function curlPostExtPos($data, $url)
        {

            $returnToken= $this->getToken();

            $data["is_2d"] = json_decode($returnToken, true)["data"]["is_3d"] == 0 ? 1 : 0;

            $response = wp_remote_post($url, array(
                'headers' => array('Content-type' => 'application/json', 'user-agent'=>$_SERVER['HTTP_USER_AGENT'], 'Authorization'=> 'Bearer ' . json_decode($returnToken, true)["data"]["token"]),
                'body' => json_encode($data),
                'method' => 'POST',
                'data_format' => 'body',
            ));
            $body = wp_remote_retrieve_body($response);

            return $body;
        }


        function getToken()
        {
// bilgiler db ceklicek.
            $url= $this->remote_url . "/ccpayment/api/token";
            $data = array('app_id'=>$this->veparapay_app_id,'app_secret'=>$this->veparapay_app_secret);
            $data=(json_encode($data));
            $token=$this->veparapay_key;
            $response = wp_remote_post($url, array(
                'headers' => array('Content-type' => 'application/json', 'user-agent'=>$_SERVER['HTTP_USER_AGENT'], 'Authorization'=> 'Bearer ' . $token),
                'body' => $data,
                'method' => 'POST',
                'data_format' => 'body',
            ));
            $body = wp_remote_retrieve_body($response);

            return $body;
            

        }
        public function currencySwich($currency)
        {
            switch ($currency) {
                case 'TRY':
                    $code = 949;
                    break;
                case 'USD':
                    $code = 840;
                    break;
                case 'EUR':
                    $code = 978;
                    break;
                case 'GBP':
                    $code = 826;
                    break;
                case 'JPY':
                    $code = 392;
                    break;

                default:
                    $code = 949;
                    break;
            }
            return $code;
        }
    }
}

add_filter('woocommerce_payment_gateways', 'woocommerce_add_vepara_checkout_form_gateway');

function woocommerce_add_vepara_checkout_form_gateway($methods)
{
    $methods[] = 'WC_Gateway_veparapay';
    return $methods;
}

function vepara_checkout_form_load_plugin_textdomain()
{
    load_plugin_textdomain('vepara-payment-module', false, plugin_basename(dirname(__FILE__)) .
        '/i18n/languages/');
}

add_action('plugins_loaded', 'vepara_checkout_form_load_plugin_textdomain');
