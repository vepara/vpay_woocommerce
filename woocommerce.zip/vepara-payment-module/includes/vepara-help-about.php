<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
$garanti_urş = plugins_url() . '/garanti-payment-module/';
?>
<!-- Latest compiled and minified CSS -->



    <style>
        #create-account-btn{
    display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
    color: #fff;
    background-color: #00683a;
    border-color: #2e6da4;
        }
        .garanti-header{
            margin-right: -15px;
    margin-left: -15px;
height: 47px;
text-decoration: none;

        }
        .garanti-header h4{
            font-size: 18px;
            margin-top: 10px;
    margin-bottom: 10px;
    font-family: inherit;
    font-weight: 500;
    line-height: 1.1;
    color: inherit;
    margin-right: -15px;
    margin-left: -15px;
        }
        .gar-md-5{
            width: 41.66666667%;
            float: left;
            position: relative;
    min-height: 1px;
    padding-right: 15px;
    padding-left: 15px;
        }

        .panel-garanti{
            margin-bottom: 20px;

    border: 1px solid transparent;
    border-radius: 4px;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 5%);
    box-shadow: 0 1px 1px rgb(0 0 0 / 5%);
    padding: 0;
        }
        hr {
            margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
        }
        .text-center {
    text-align: center;
}
    </style>
<div class="panel-garanti">
          
            
    <div class="row garanti-header">

        <div class="gar-xs-6 gar-md-5 text-center co">
            <h4>vepara</h4>
            <h4>Hızlı Güvenli ve Kolay</h4>
        </div>
        <div class="col-xs-12 gar-md-5 text-center">
            <a href="https://www.vepara.com.tr/sanal-pos/" class="" id="create-account-btn">vepara SanalPOS'a başvurun</a><br />
            vepara SanalPOS'unuz varsa ?<a href="https://app.vepara.com.tr/merchant/login"> Hesabınıza giriş yapın</a>
        </div>

    </div>

    <hr />



</div>